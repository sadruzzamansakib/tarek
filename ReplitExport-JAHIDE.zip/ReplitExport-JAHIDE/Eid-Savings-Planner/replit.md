# Workspace

## Overview

pnpm workspace monorepo using TypeScript. The primary app is রোজা ঈদের গরুর ফান্ড, a Bangla web app for tracking monthly savings toward buying a cattle for Roza Eid. Users sign in to view shared cloud-saved fund data; the first signed-in account becomes the admin account and can manage fund settings, add/remove members, and record contributions. Later accounts are viewer accounts by default.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite (`artifacts/qurbani-fund`)
- **Auth**: Clerk-managed sign-in/sign-up
- **API framework**: Express 5 (`artifacts/api-server`)
- **Database**: PostgreSQL + Drizzle ORM (`lib/db/src/schema/qurbani.ts`)
- **Validation**: Zod (`zod/v4`), `drizzle-zod`, generated OpenAPI Zod schemas
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/qurbani-fund run dev` — run রোজা ঈদের গরুর ফান্ড web app locally

## রোজা ঈদের গরুর ফান্ড Data Model

- `qurbani_funds`: per-user fund target, monthly target, Eid date, and notes
- `qurbani_members`: per-user member list with phone, pledge amount, and active/inactive status
- `qurbani_contributions`: monthly contribution records linked to members
- `qurbani_activities`: recent fund activity feed
- `qurbani_admins`: admin account registry; first authenticated user is automatically promoted to admin

## API Surface

The OpenAPI contract in `lib/api-spec/openapi.yaml` defines protected endpoints for current role, fund settings, dashboard summary, activity feed, member CRUD, and contribution CRUD. Generated React hooks are consumed by the web app from `@workspace/api-client-react`. Write operations are restricted to admin users on the server.

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
