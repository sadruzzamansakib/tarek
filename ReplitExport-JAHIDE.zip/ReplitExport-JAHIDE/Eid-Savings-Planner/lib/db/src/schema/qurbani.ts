import {
  boolean,
  numeric,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

export const qurbaniFundsTable = pgTable("qurbani_funds", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull().unique(),
  title: text("title").notNull(),
  targetAmount: numeric("target_amount", { precision: 12, scale: 2, mode: "number" }).notNull(),
  monthlyTarget: numeric("monthly_target", { precision: 12, scale: 2, mode: "number" }).notNull(),
  eidDate: text("eid_date").notNull(),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const qurbaniMembersTable = pgTable("qurbani_members", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  phone: text("phone").notNull().default(""),
  monthlyPledge: numeric("monthly_pledge", { precision: 12, scale: 2, mode: "number" }).notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const qurbaniContributionsTable = pgTable("qurbani_contributions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull(),
  memberId: uuid("member_id").notNull().references(() => qurbaniMembersTable.id),
  amount: numeric("amount", { precision: 12, scale: 2, mode: "number" }).notNull(),
  month: text("month").notNull(),
  note: text("note").notNull().default(""),
  paidAt: timestamp("paid_at", { withTimezone: true }).defaultNow().notNull(),
});

export const qurbaniActivitiesTable = pgTable("qurbani_activities", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull(),
  type: text("type").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const qurbaniAdminsTable = pgTable("qurbani_admins", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});