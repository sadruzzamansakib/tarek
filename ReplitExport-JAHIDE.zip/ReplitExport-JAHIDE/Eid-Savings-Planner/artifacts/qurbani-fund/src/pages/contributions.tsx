import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { 
  useListContributions, getListContributionsQueryKey,
  useCreateContribution, useDeleteContribution,
  useListMembers, getListMembersQueryKey,
  useGetDashboard, getGetDashboardQueryKey,
  useGetMe, getGetMeQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Plus, Trash2, CalendarDays, Banknote } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format, parseISO } from "date-fns";

const contributionSchema = z.object({
  memberId: z.string().min(1, "সদস্য নির্বাচন করুন"),
  amount: z.coerce.number().min(1, "সঠিক পরিমাণ দিন"),
  month: z.string().regex(/^[0-9]{4}-[0-9]{2}$/, "মাস নির্বাচন করুন"),
  note: z.string().optional().default(""),
});

// Generate next 12 months for dropdown
const generateMonths = () => {
  const months = [];
  const d = new Date();
  // Start from 2 months ago to 10 months ahead
  d.setMonth(d.getMonth() - 2);
  
  for (let i = 0; i < 12; i++) {
    const value = format(d, "yyyy-MM");
    const label = format(d, "MMMM yyyy");
    months.push({ value, label });
    d.setMonth(d.getMonth() + 1);
  }
  return months;
};

export default function Contributions() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const currentMonthValue = format(new Date(), "yyyy-MM");

  const { data: contributions, isLoading: isLoadingCont } = useListContributions({
    query: { queryKey: getListContributionsQueryKey() }
  });
  
  const { data: members, isLoading: isLoadingMembers } = useListMembers({
    query: { queryKey: getListMembersQueryKey() }
  });
  const { data: me } = useGetMe({
    query: { queryKey: getGetMeQueryKey() }
  });
  const isAdmin = me?.isAdmin === true;

  const createContribution = useCreateContribution();
  const deleteContribution = useDeleteContribution();

  const form = useForm<z.infer<typeof contributionSchema>>({
    resolver: zodResolver(contributionSchema),
    defaultValues: {
      memberId: "",
      amount: 0,
      month: currentMonthValue,
      note: "",
    }
  });

  const onSubmit = (values: z.infer<typeof contributionSchema>) => {
    createContribution.mutate({ data: { 
      memberId: values.memberId, 
      amount: values.amount, 
      month: values.month,
      note: values.note || ""
    } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListContributionsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        setIsCreateOpen(false);
        form.reset({ month: currentMonthValue, note: "", amount: 0, memberId: "" });
        toast({ title: "সফল", description: "চাঁদা সফলভাবে যোগ করা হয়েছে" });
      }
    });
  };

  const handleDelete = (id: string) => {
    deleteContribution.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListContributionsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        toast({ title: "সফল", description: "রেকর্ড মুছে ফেলা হয়েছে" });
      }
    });
  };

  const handleMemberSelect = (val: string) => {
    form.setValue("memberId", val);
    const member = members?.find(m => m.id === val);
    if (member) {
      form.setValue("amount", member.monthlyPledge);
    }
  };

  const monthsList = generateMonths();

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground">চাঁদা আদায়</h1>
          <p className="text-muted-foreground mt-1">সদস্যদের মাসিক চাঁদার রেকর্ড</p>
        </div>

        {isAdmin ? (
          <Dialog open={isCreateOpen} onOpenChange={(open) => { setIsCreateOpen(open); if(!open) form.reset({month: currentMonthValue}); }}>
            <DialogTrigger asChild>
              <Button className="rounded-full shadow-sm hover-elevate bg-primary text-primary-foreground">
                <Plus className="w-4 h-4 mr-2" />
                চাঁদা এন্ট্রি
              </Button>
            </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="font-serif">নতুন চাঁদা এন্ট্রি</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <FormField control={form.control} name="memberId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>সদস্য</FormLabel>
                    <Select onValueChange={handleMemberSelect} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="সদস্য নির্বাচন করুন" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {members?.filter(m => m.active).map(m => (
                          <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="month" render={({ field }) => (
                    <FormItem>
                      <FormLabel>মাস</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="মাস" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {monthsList.map(m => (
                            <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                  
                  <FormField control={form.control} name="amount" render={({ field }) => (
                    <FormItem>
                      <FormLabel>পরিমাণ (৳)</FormLabel>
                      <FormControl><Input type="number" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
                
                <FormField control={form.control} name="note" render={({ field }) => (
                  <FormItem>
                    <FormLabel>নোট (ঐচ্ছিক)</FormLabel>
                    <FormControl><Input placeholder="যেমন: বিকাশ বা ক্যাশ" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                
                <Button type="submit" className="w-full mt-4" disabled={createContribution.isPending || isLoadingMembers}>
                  {createContribution.isPending ? "যোগ করা হচ্ছে..." : "জমা করুন"}
                </Button>
              </form>
            </Form>
          </DialogContent>
          </Dialog>
        ) : (
          <div className="rounded-full border border-border bg-card px-4 py-2 text-sm text-muted-foreground">
            সাধারণ একাউন্ট: চাঁদার হিসাব শুধু দেখা যাবে
          </div>
        )}
      </div>

      <Card className="shadow-sm border-border/50 overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead>তারিখ</TableHead>
                <TableHead>সদস্য</TableHead>
                <TableHead>মাস</TableHead>
                <TableHead>পরিমাণ</TableHead>
                {isAdmin && <TableHead className="text-right">অ্যাকশন</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoadingCont ? (
                <TableRow>
                  <TableCell colSpan={isAdmin ? 5 : 4} className="h-24 text-center">লোড হচ্ছে...</TableCell>
                </TableRow>
              ) : contributions && contributions.length > 0 ? (
                contributions.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">
                      {format(new Date(c.paidAt), 'dd MMM yyyy')}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold">
                          {c.memberName.charAt(0)}
                        </div>
                        {c.memberName}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center text-muted-foreground gap-1 text-sm">
                        <CalendarDays className="w-3 h-3" />
                        {c.month}
                      </div>
                    </TableCell>
                    <TableCell className="font-sans font-semibold text-primary">
                      ৳ {c.amount.toLocaleString('en-IN')}
                    </TableCell>
                    {isAdmin && (
                    <TableCell className="text-right">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>নিশ্চিত তো?</AlertDialogTitle>
                            <AlertDialogDescription>
                              এই চাঁদার রেকর্ডটি মুছে ফেলা হবে। এটি ফান্ডের মোট হিসাব থেকে বাদ যাবে।
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>বাতিল</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDelete(c.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                              মুছুন
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                    )}
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={isAdmin ? 5 : 4} className="h-32 text-center text-muted-foreground">
                    <div className="flex flex-col items-center justify-center">
                      <Banknote className="w-8 h-8 text-muted mb-2" />
                      <p>কোনো চাঁদা এখনো আদায় হয়নি</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
