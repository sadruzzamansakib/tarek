import { useState } from "react";
import { useGetDashboard, getGetDashboardQueryKey, useGetActivity, getGetActivityQueryKey, useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Activity, Users, Banknote, Target, ArrowUpRight, TrendingUp } from "lucide-react";
import { format } from "date-fns";

export default function Dashboard() {
  const { data: dashboard, isLoading: isLoadingDashboard } = useGetDashboard({
    query: { queryKey: getGetDashboardQueryKey() }
  });
  
  const { data: activities, isLoading: isLoadingActivity } = useGetActivity({
    query: { queryKey: getGetActivityQueryKey() }
  });
  const { data: me } = useGetMe({
    query: { queryKey: getGetMeQueryKey() }
  });

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground">ড্যাশবোর্ড</h1>
          <p className="text-muted-foreground mt-1">রোজা ঈদের গরুর ফান্ডের বর্তমান অবস্থা ও অগ্রগতি</p>
        </div>
        <div className="rounded-full border border-primary/20 bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
          {me?.isAdmin ? "এডমিন একাউন্ট" : "সাধারণ একাউন্ট: শুধু দেখা যাবে"}
        </div>
      </div>

      {isLoadingDashboard ? (
        <DashboardSkeleton />
      ) : dashboard ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-card hover-elevate border-primary/20 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">মোট সঞ্চয়</CardTitle>
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Banknote className="w-4 h-4 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-sans">৳ {dashboard.totalSaved.toLocaleString('en-IN')}</div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                  <Target className="w-3 h-3" />
                  টার্গেট: ৳ {dashboard.targetAmount.toLocaleString('en-IN')}
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-card hover-elevate border-accent/20 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">বাকি আছে</CardTitle>
                <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-accent" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-sans text-accent">৳ {dashboard.remainingAmount.toLocaleString('en-IN')}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  আর {dashboard.monthsRemaining} মাস বাকি
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card hover-elevate border-blue-500/20 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">চলতি মাসের আদায়</CardTitle>
                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center">
                  <ArrowUpRight className="w-4 h-4 text-blue-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-sans">৳ {dashboard.currentMonthCollected.toLocaleString('en-IN')}</div>
                <p className="text-xs text-muted-foreground mt-1 text-balance">
                  লক্ষ্যমাত্রা: ৳ {dashboard.currentMonthExpected.toLocaleString('en-IN')}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card hover-elevate border-purple-500/20 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">সক্রিয় সদস্য</CardTitle>
                <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center">
                  <Users className="w-4 h-4 text-purple-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-sans">{dashboard.activeMembers} জন</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {dashboard.inactiveMembers > 0 ? `${dashboard.inactiveMembers} জন নিষ্ক্রিয়` : 'সবাই সক্রিয়'}
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="shadow-sm border-border/50">
            <CardHeader>
              <CardTitle>ফান্ডের অগ্রগতি</CardTitle>
              <CardDescription>মোট টার্গেটের তুলনায় বর্তমান সঞ্চয়</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between text-sm font-medium">
                <span>{dashboard.progressPercent.toFixed(1)}% সম্পন্ন</span>
                <span className="text-muted-foreground">৳ {dashboard.totalSaved.toLocaleString('en-IN')} / ৳ {dashboard.targetAmount.toLocaleString('en-IN')}</span>
              </div>
              <Progress value={dashboard.progressPercent} className="h-3" />
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="shadow-sm border-border/50">
              <CardHeader>
                <CardTitle>সদস্যদের অবদান</CardTitle>
                <CardDescription>কে কত টাকা জমা দিয়েছেন</CardDescription>
              </CardHeader>
              <CardContent>
                {dashboard.memberTotals.length > 0 ? (
                  <div className="space-y-4">
                    {dashboard.memberTotals.map((mt) => (
                      <div key={mt.memberId} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-xs font-medium text-secondary-foreground">
                            {mt.memberName.charAt(0)}
                          </div>
                          <span className="font-medium text-sm">{mt.memberName}</span>
                        </div>
                        <span className="font-sans font-semibold text-sm">৳ {mt.total.toLocaleString('en-IN')}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-8 text-center text-muted-foreground text-sm">
                    কোনো অবদান পাওয়া যায়নি
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card className="shadow-sm border-border/50">
              <CardHeader>
                <CardTitle>সাম্প্রতিক কার্যক্রম</CardTitle>
                <CardDescription>ফান্ডের সর্বশেষ আপডেট</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingActivity ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="flex gap-3">
                        <Skeleton className="w-8 h-8 rounded-full shrink-0" />
                        <div className="space-y-2 flex-1">
                          <Skeleton className="h-4 w-full" />
                          <Skeleton className="h-3 w-24" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : activities && activities.length > 0 ? (
                  <div className="space-y-6">
                    {activities.map((activity) => (
                      <div key={activity.id} className="flex gap-4 relative">
                        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0 z-10">
                          <Activity className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <div className="pt-1 flex-1">
                          <p className="text-sm font-medium text-foreground">{activity.message}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {format(new Date(activity.createdAt), 'dd MMM yyyy, hh:mm a')}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-8 text-center text-muted-foreground text-sm">
                    কোনো সাম্প্রতিক কার্যক্রম নেই
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </>
      ) : (
        <div className="py-12 text-center text-muted-foreground">
          তথ্য পাওয়া যায়নি
        </div>
      )}
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-8 animate-pulse">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map(i => (
          <Card key={i} className="bg-card">
            <CardHeader className="pb-2"><Skeleton className="h-4 w-20" /></CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-32 mb-2" />
              <Skeleton className="h-3 w-24" />
            </CardContent>
          </Card>
        ))}
      </div>
      <Card>
        <CardHeader><Skeleton className="h-6 w-32 mb-2" /><Skeleton className="h-4 w-48" /></CardHeader>
        <CardContent><Skeleton className="h-3 w-full" /></CardContent>
      </Card>
    </div>
  );
}
