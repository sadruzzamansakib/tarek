import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { 
  useListMembers, getListMembersQueryKey, 
  useCreateMember, useUpdateMember, useDeleteMember,
  useGetDashboard, getGetDashboardQueryKey,
  useGetMe, getGetMeQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Plus, User, Phone, Trash2, Edit2, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const memberSchema = z.object({
  name: z.string().min(1, "নাম লিখুন"),
  phone: z.string().optional().default(""),
  monthlyPledge: z.coerce.number().min(0, "সঠিক পরিমাণ দিন"),
  active: z.boolean().default(true),
});

export default function Members() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editMemberId, setEditMemberId] = useState<string | null>(null);

  const { data: members, isLoading } = useListMembers({
    query: { queryKey: getListMembersQueryKey() }
  });
  const { data: me } = useGetMe({
    query: { queryKey: getGetMeQueryKey() }
  });
  const isAdmin = me?.isAdmin === true;

  const createMember = useCreateMember();
  const updateMember = useUpdateMember();
  const deleteMember = useDeleteMember();

  const form = useForm<z.infer<typeof memberSchema>>({
    resolver: zodResolver(memberSchema),
    defaultValues: {
      name: "",
      phone: "",
      monthlyPledge: 1000,
      active: true,
    }
  });

  const onSubmit = (values: z.infer<typeof memberSchema>) => {
    if (editMemberId) {
      updateMember.mutate({ id: editMemberId, data: values }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
          setEditMemberId(null);
          toast({ title: "সফল", description: "সদস্যের তথ্য আপডেট হয়েছে" });
        }
      });
    } else {
      createMember.mutate({ data: { name: values.name, phone: values.phone || "", monthlyPledge: values.monthlyPledge } }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
          setIsCreateOpen(false);
          form.reset();
          toast({ title: "সফল", description: "নতুন সদস্য যোগ করা হয়েছে" });
        }
      });
    }
  };

  const handleEdit = (member: any) => {
    form.reset({
      name: member.name,
      phone: member.phone || "",
      monthlyPledge: member.monthlyPledge,
      active: member.active
    });
    setEditMemberId(member.id);
  };

  const handleDelete = (id: string) => {
    deleteMember.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        toast({ title: "সফল", description: "সদস্যকে মুছে ফেলা হয়েছে" });
      }
    });
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground">সদস্যগণ</h1>
          <p className="text-muted-foreground mt-1">ফান্ডের সকল সদস্য ও তাদের চাঁদার হার</p>
        </div>

        {isAdmin ? (
          <Dialog open={isCreateOpen} onOpenChange={(open) => { setIsCreateOpen(open); if(!open) { form.reset(); setEditMemberId(null); } }}>
            <DialogTrigger asChild>
              <Button className="rounded-full shadow-sm hover-elevate bg-primary text-primary-foreground">
                <Plus className="w-4 h-4 mr-2" />
                নতুন সদস্য
              </Button>
            </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="font-serif">নতুন সদস্য যোগ করুন</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>নাম</FormLabel>
                    <FormControl><Input placeholder="সদস্যের নাম" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="phone" render={({ field }) => (
                  <FormItem>
                    <FormLabel>ফোন নম্বর (ঐচ্ছিক)</FormLabel>
                    <FormControl><Input placeholder="01XXX-XXXXXX" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="monthlyPledge" render={({ field }) => (
                  <FormItem>
                    <FormLabel>মাসিক চাঁদা (৳)</FormLabel>
                    <FormControl><Input type="number" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <Button type="submit" className="w-full mt-4" disabled={createMember.isPending}>
                  {createMember.isPending ? "যোগ করা হচ্ছে..." : "যোগ করুন"}
                </Button>
              </form>
            </Form>
          </DialogContent>
          </Dialog>
        ) : (
          <div className="rounded-full border border-border bg-card px-4 py-2 text-sm text-muted-foreground">
            সাধারণ একাউন্ট: সদস্য তালিকা শুধু দেখা যাবে
          </div>
        )}
      </div>

      <Dialog open={isAdmin && !!editMemberId} onOpenChange={(open) => { if(!open) setEditMemberId(null); }}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="font-serif">সদস্য তথ্য আপডেট</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
              <FormField control={form.control} name="name" render={({ field }) => (
                <FormItem>
                  <FormLabel>নাম</FormLabel>
                  <FormControl><Input {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="phone" render={({ field }) => (
                <FormItem>
                  <FormLabel>ফোন নম্বর</FormLabel>
                  <FormControl><Input {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="monthlyPledge" render={({ field }) => (
                <FormItem>
                  <FormLabel>মাসিক চাঁদা (৳)</FormLabel>
                  <FormControl><Input type="number" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="active" render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">সক্রিয়</FormLabel>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                </FormItem>
              )} />
              <Button type="submit" className="w-full mt-4" disabled={updateMember.isPending}>
                {updateMember.isPending ? "আপডেট হচ্ছে..." : "আপডেট করুন"}
              </Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1,2,3,4,5].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6 space-y-4">
                <div className="w-12 h-12 bg-muted rounded-full" />
                <div className="h-4 bg-muted rounded w-2/3" />
                <div className="h-3 bg-muted rounded w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : members && members.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {members.map((member) => (
            <Card key={member.id} className={`shadow-sm border-border/50 hover-elevate transition-all ${!member.active ? 'opacity-60 grayscale-[0.5]' : ''}`}>
              <CardContent className="p-6 relative">
                {isAdmin && (
                <div className="absolute top-4 right-4 flex items-center gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={() => handleEdit(member)}>
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>আপনি কি নিশ্চিত?</AlertDialogTitle>
                        <AlertDialogDescription>
                          এই সদস্যকে ডিলিট করলে তার সব অবদান মুছে যাবে। এই কাজটি পূর্বাবস্থায় ফেরানো যাবে না।
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>বাতিল</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(member.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                          ডিলিট করুন
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
                )}
                
                <div className="flex flex-col items-center text-center space-y-3">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center text-2xl font-serif text-white shadow-sm ${member.active ? 'bg-primary' : 'bg-muted-foreground'}`}>
                    {member.name.charAt(0)}
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold">{member.name}</h3>
                    <div className="flex items-center justify-center gap-1 text-sm text-muted-foreground mt-1">
                      <Phone className="w-3 h-3" />
                      {member.phone || "নম্বর নেই"}
                    </div>
                  </div>
                  
                  <div className="w-full pt-4 mt-2 border-t border-border/50 flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">মাসিক চাঁদা</span>
                    <span className="font-sans font-bold text-lg text-primary">৳ {member.monthlyPledge.toLocaleString('en-IN')}</span>
                  </div>
                  
                  {!member.active && (
                    <div className="w-full bg-muted text-muted-foreground text-xs py-1 rounded-md mt-2 font-medium">
                      নিষ্ক্রিয়
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-center border rounded-2xl border-dashed bg-card/50">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            <User className="w-8 h-8 text-primary" />
          </div>
          <h3 className="text-xl font-serif font-medium mb-2">কোনো সদস্য নেই</h3>
          <p className="text-muted-foreground max-w-md mb-6">
            ফান্ডে সঞ্চয় শুরু করতে প্রথমে সদস্যদের যোগ করুন। এরপর তারা মাসিক চাঁদা জমা দিতে পারবেন।
          </p>
          <Button onClick={() => setIsCreateOpen(true)} className="rounded-full">
            <Plus className="w-4 h-4 mr-2" /> সদস্য যোগ করুন
          </Button>
        </div>
      )}
    </div>
  );
}
