import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="min-h-[100dvh] w-full flex flex-col bg-background selection:bg-primary/20">
      <header className="px-6 h-20 flex items-center justify-between border-b border-border/40 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-serif text-2xl font-bold shadow-sm">
            ক
          </div>
          <span className="font-serif text-2xl font-semibold tracking-tight text-foreground">রোজা ঈদের গরুর ফান্ড</span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/sign-in" className="text-sm font-medium hover:text-primary transition-colors hidden sm:block">লগইন করুন</Link>
          <Button asChild className="rounded-full shadow-sm hover-elevate">
            <Link href="/sign-up">নতুন ফান্ড খুলুন</Link>
          </Button>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-6 text-center">
        <div className="max-w-3xl space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary/50 text-secondary-foreground text-sm font-medium border border-border/50 mb-4">
            <span className="w-2 h-2 rounded-full bg-accent animate-pulse"></span>
            <span>রোজা ঈদের গরুর জন্য প্রস্তুতি নিন</span>
          </div>
          
          <h1 className="text-5xl sm:text-6xl md:text-7xl font-serif text-foreground leading-[1.1] text-balance">
            পরিবারের <span className="text-primary italic">রোজা ঈদের গরুর জন্য</span> ফান্ড এখন আপনার হাতের মুঠোয়
          </h1>
          
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            আত্মীয়-স্বজন ও বন্ধুদের সাথে মিলে মাসিক চাঁদার মাধ্যমে রোজা ঈদের গরুর জন্য সঞ্চয় করুন। হিসাব রাখুন স্বচ্ছ ও সহজে।
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button asChild size="lg" className="rounded-full px-8 text-base shadow-lg shadow-primary/20 hover-elevate w-full sm:w-auto h-14">
              <Link href="/sign-up">শুরু করুন</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="rounded-full px-8 text-base w-full sm:w-auto h-14 border-2 hover:bg-secondary/50">
              <Link href="/sign-in">আমার ফান্ড</Link>
            </Button>
          </div>
        </div>

        <div className="mt-24 grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-12 duration-1000 delay-300 fill-mode-both">
          {[
            {
              title: "সহজ হিসাব",
              desc: "কে কত চাঁদা দিয়েছে, কত বাকি আছে সব হিসাব রাখুন এক জায়গায়।"
            },
            {
              title: "স্বচ্ছতা",
              desc: "ফান্ডের সকল সদস্য তাদের অবদান ও ফান্ডের অগ্রগতি দেখতে পারবেন।"
            },
            {
              title: "লক্ষ্য নির্ধারণ",
              desc: "রোজা ঈদের গরুর জন্য বাজেট নির্ধারণ করুন এবং মাসিক চাঁদার টার্গেট সেট করুন।"
            }
          ].map((feature, i) => (
            <div key={i} className="flex flex-col items-center sm:items-start text-center sm:text-left space-y-3 p-6 rounded-2xl bg-card border border-border/50 shadow-sm">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-serif text-xl">
                {i + 1}
              </div>
              <h3 className="font-serif text-xl font-medium">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </main>

      <footer className="py-8 text-center text-sm text-muted-foreground border-t border-border/40 mt-auto bg-card/30">
        &copy; {new Date().getFullYear()} রোজা ঈদের গরুর ফান্ড। আপনার বিশ্বস্ত পারিবারিক খাতা।
      </footer>
    </div>
  );
}
