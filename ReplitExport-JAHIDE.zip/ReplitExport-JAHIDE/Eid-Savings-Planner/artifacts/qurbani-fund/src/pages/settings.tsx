import { useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useGetFund, getGetFundQueryKey, useUpdateFund, getGetDashboardQueryKey, useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const fundSchema = z.object({
  title: z.string().min(1, "ফান্ডের নাম লিখুন"),
  targetAmount: z.coerce.number().min(0, "সঠিক টার্গেট দিন"),
  monthlyTarget: z.coerce.number().min(0, "সঠিক মাসিক টার্গেট দিন"),
  eidDate: z.string().min(1, "ঈদের তারিখ দিন"),
  notes: z.string().optional().default(""),
});

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: fund, isLoading } = useGetFund({
    query: { queryKey: getGetFundQueryKey() }
  });
  const { data: me } = useGetMe({
    query: { queryKey: getGetMeQueryKey() }
  });
  const isAdmin = me?.isAdmin === true;
  
  const updateFund = useUpdateFund();
  
  const form = useForm<z.infer<typeof fundSchema>>({
    resolver: zodResolver(fundSchema),
    defaultValues: {
      title: "",
      targetAmount: 0,
      monthlyTarget: 0,
      eidDate: format(new Date(), "yyyy-MM-dd"),
      notes: "",
    }
  });

  const initializedForId = useRef<string | null>(null);

  useEffect(() => {
    if (fund && initializedForId.current !== fund.id) {
      initializedForId.current = fund.id;
      form.reset({
        title: fund.title,
        targetAmount: fund.targetAmount,
        monthlyTarget: fund.monthlyTarget,
        eidDate: fund.eidDate,
        notes: fund.notes || "",
      });
    }
  }, [fund, form]);

  const onSubmit = (values: z.infer<typeof fundSchema>) => {
    updateFund.mutate({ data: values }, {
      onSuccess: (data) => {
        // Patch cache locally to avoid full refetch that resets form if not careful
        queryClient.setQueryData(getGetFundQueryKey(), data);
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        toast({ title: "সফল", description: "ফান্ডের সেটিংস আপডেট হয়েছে" });
      }
    });
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-3xl mx-auto">
      <div>
        <h1 className="text-3xl font-serif font-bold text-foreground">সেটিংস</h1>
        <p className="text-muted-foreground mt-1">রোজা ঈদের গরুর ফান্ডের মূল সেটিংস কনফিগার করুন</p>
      </div>

      {!isAdmin && (
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="p-6">
            <h2 className="font-serif text-xl font-semibold text-foreground">শুধু এডমিন পরিবর্তন করতে পারবে</h2>
            <p className="text-muted-foreground mt-2">এই একাউন্টটি সাধারণ একাউন্ট। আপনি ফান্ডের তথ্য দেখতে পারবেন, কিন্তু সেটিংস পরিবর্তন করতে হলে এডমিন একাউন্ট দিয়ে লগইন করতে হবে।</p>
          </CardContent>
        </Card>
      )}

      <Card className="shadow-sm border-border/50">
        <CardHeader>
          <CardTitle className="font-serif text-xl">ফান্ড কনফিগারেশন</CardTitle>
          <CardDescription>আপনার ফান্ডের লক্ষ্যমাত্রা ও বিবরণ আপডেট করুন</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4 animate-pulse">
              <div className="h-10 bg-muted rounded w-full" />
              <div className="h-10 bg-muted rounded w-full" />
              <div className="h-10 bg-muted rounded w-full" />
            </div>
          ) : (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField control={form.control} name="title" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-base">ফান্ডের নাম</FormLabel>
                    <FormControl><Input className="h-12" disabled={!isAdmin} {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField control={form.control} name="targetAmount" render={({ field }) => (
                    <FormItem>
                      <FormLabel>মোট টার্গেট (৳)</FormLabel>
                      <FormControl><Input type="number" className="h-12 font-sans" disabled={!isAdmin} {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  
                  <FormField control={form.control} name="monthlyTarget" render={({ field }) => (
                    <FormItem>
                      <FormLabel>মাসিক টার্গেট (৳)</FormLabel>
                      <FormControl><Input type="number" className="h-12 font-sans" disabled={!isAdmin} {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
                
                <FormField control={form.control} name="eidDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>ঈদের সম্ভাব্য তারিখ</FormLabel>
                    <FormControl><Input type="date" className="h-12" disabled={!isAdmin} {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                
                <FormField control={form.control} name="notes" render={({ field }) => (
                  <FormItem>
                    <FormLabel>বিবরণ / নোট</FormLabel>
                    <FormControl><Textarea className="resize-none h-24" placeholder="ফান্ড সম্পর্কিত যেকোনো নোট" disabled={!isAdmin} {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                <div className="pt-4 border-t border-border flex justify-end">
                  <Button type="submit" size="lg" disabled={!isAdmin || updateFund.isPending} className="rounded-full px-8">
                    {updateFund.isPending ? "সংরক্ষণ করা হচ্ছে..." : "সংরক্ষণ করুন"}
                  </Button>
                </div>
              </form>
            </Form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
