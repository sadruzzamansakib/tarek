import { Link, useLocation } from "wouter";
import { useUser, useClerk } from "@clerk/react";
import { 
  LayoutDashboard, 
  Users, 
  Banknote, 
  Settings, 
  LogOut,
  Menu
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";

const navItems = [
  { href: "/app", label: "ড্যাশবোর্ড", icon: LayoutDashboard },
  { href: "/app/members", label: "সদস্যগণ", icon: Users },
  { href: "/app/contributions", label: "চাঁদা আদায়", icon: Banknote },
  { href: "/app/settings", label: "সেটিংস", icon: Settings },
];

function SidebarContent() {
  const [location] = useLocation();
  const { data: me } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const visibleNavItems = me?.isAdmin ? navItems : navItems.filter((item) => item.href !== "/app/settings");
  
  return (
    <div className="flex flex-col h-full bg-sidebar border-r border-sidebar-border w-64 md:w-72">
      <div className="h-20 flex items-center px-6 border-b border-sidebar-border/50">
        <Link href="/app" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sidebar-primary flex items-center justify-center text-sidebar-primary-foreground font-serif text-2xl font-bold shadow-sm">
            ক
          </div>
          <span className="font-serif text-xl font-semibold text-sidebar-foreground">রোজা ঈদের গরুর ফান্ড</span>
        </Link>
      </div>
      
      <nav className="flex-1 py-6 px-4 space-y-2">
        {visibleNavItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <span className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors cursor-pointer ${
                isActive 
                  ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium shadow-sm" 
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
              }`}>
                <item.icon className="w-5 h-5" />
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-sidebar-border/50">
        <UserProfile />
      </div>
    </div>
  );
}

function UserProfile() {
  const { user } = useUser();
  const { signOut } = useClerk();
  const { data: me } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  
  if (!user) return null;
  
  const initials = user.firstName ? user.firstName[0] : user.emailAddresses[0].emailAddress[0].toUpperCase();
  
  return (
    <div className="flex items-center justify-between bg-card p-3 rounded-xl border border-border shadow-sm">
      <div className="flex items-center gap-3 overflow-hidden">
        <Avatar className="w-10 h-10 border border-border">
          <AvatarImage src={user.imageUrl} />
          <AvatarFallback className="bg-primary/10 text-primary font-medium">{initials}</AvatarFallback>
        </Avatar>
        <div className="flex flex-col overflow-hidden">
          <span className="text-sm font-medium truncate">{user.firstName || "User"}</span>
          <span className="text-xs text-muted-foreground truncate">{user.emailAddresses[0].emailAddress}</span>
          <span className="text-[11px] text-primary font-medium">{me?.isAdmin ? "এডমিন একাউন্ট" : "সাধারণ একাউন্ট"}</span>
        </div>
      </div>
      <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive shrink-0" onClick={() => signOut()}>
        <LogOut className="w-4 h-4" />
      </Button>
    </div>
  );
}

export function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-[100dvh] bg-background">
      {/* Desktop Sidebar */}
      <div className="hidden md:block shrink-0">
        <SidebarContent />
      </div>
      
      {/* Mobile Header & Sidebar */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-background border-b border-border flex items-center px-4 z-50">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="mr-3">
              <Menu className="w-6 h-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-72">
            <SidebarContent />
          </SheetContent>
        </Sheet>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-serif text-lg font-bold">
            ক
          </div>
          <span className="font-serif text-lg font-semibold">রোজা ঈদের গরুর ফান্ড</span>
        </div>
      </div>
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 md:pt-0 pt-16 h-[100dvh] overflow-y-auto">
        {children}
      </main>
    </div>
  );
}
