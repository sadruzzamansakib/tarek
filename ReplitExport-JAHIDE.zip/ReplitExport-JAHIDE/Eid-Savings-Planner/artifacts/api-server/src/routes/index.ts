import { Router, type IRouter } from "express";
import healthRouter from "./health";
import qurbaniRouter from "./qurbani";

const router: IRouter = Router();

router.use(healthRouter);
router.use(qurbaniRouter);

export default router;
