import { getAuth } from "@clerk/express";
import {
  CreateContributionBody,
  CreateMemberBody,
  GetActivityResponse,
  GetDashboardResponse,
  GetFundResponse,
  GetMeResponse,
  ListContributionsResponse,
  ListMembersResponse,
  UpdateContributionBody,
  UpdateContributionParams,
  UpdateContributionResponse,
  UpdateFundBody,
  UpdateFundResponse,
  UpdateMemberBody,
  UpdateMemberParams,
  UpdateMemberResponse,
  DeleteContributionParams,
  DeleteMemberParams,
} from "@workspace/api-zod";
import { db } from "@workspace/db";
import {
  qurbaniAdminsTable,
  qurbaniActivitiesTable,
  qurbaniContributionsTable,
  qurbaniFundsTable,
  qurbaniMembersTable,
} from "@workspace/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { Router, type IRouter, type Request, type RequestHandler } from "express";

type AuthedRequest = Request & {
  userId?: string;
};

const router: IRouter = Router();
const SHARED_FUND_USER_ID = "shared-roza-eid-cattle-fund";

const requireAuth: RequestHandler = (req, res, next) => {
  const auth = getAuth(req);
  const userId = auth?.sessionClaims?.userId || auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  (req as AuthedRequest).userId = userId;
  next();
};

function userIdFrom(req: Request) {
  const userId = (req as AuthedRequest).userId;
  if (!userId) {
    throw new Error("Authenticated user missing");
  }
  return userId;
}

async function isAdminUser(userId: string) {
  const existingAdmins = await db.select().from(qurbaniAdminsTable).limit(1);
  if (!existingAdmins[0]) {
    await db.insert(qurbaniAdminsTable).values({ userId }).onConflictDoNothing();
    return true;
  }

  const currentAdmin = await db
    .select()
    .from(qurbaniAdminsTable)
    .where(eq(qurbaniAdminsTable.userId, userId))
    .limit(1);
  return Boolean(currentAdmin[0]);
}

async function accessFor(req: Request) {
  const userId = userIdFrom(req);
  const isAdmin = await isAdminUser(userId);
  return { userId, isAdmin, fundUserId: SHARED_FUND_USER_ID };
}

async function requireAdmin(req: Request, res: Parameters<RequestHandler>[1]) {
  const access = await accessFor(req);
  if (!access.isAdmin) {
    res.status(403).json({ error: "Only admin can change this fund" });
    return null;
  }
  return access;
}

function toIso(value: Date | string) {
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function toFund(row: typeof qurbaniFundsTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    targetAmount: row.targetAmount,
    monthlyTarget: row.monthlyTarget,
    eidDate: row.eidDate,
    notes: row.notes,
    createdAt: toIso(row.createdAt),
    updatedAt: toIso(row.updatedAt),
  };
}

function toMember(row: typeof qurbaniMembersTable.$inferSelect) {
  return {
    id: row.id,
    name: row.name,
    phone: row.phone,
    monthlyPledge: row.monthlyPledge,
    active: row.active,
    createdAt: toIso(row.createdAt),
  };
}

function monthDiff(from: Date, to: Date) {
  const start = new Date(from.getFullYear(), from.getMonth(), 1);
  const end = new Date(to.getFullYear(), to.getMonth(), 1);
  return Math.max(
    0,
    (end.getFullYear() - start.getFullYear()) * 12 + end.getMonth() - start.getMonth() + 1,
  );
}

async function addActivity(userId: string, type: string, message: string) {
  await db.insert(qurbaniActivitiesTable).values({ userId, type, message });
}

async function ensureFund(userId: string) {
  const existing = await db
    .select()
    .from(qurbaniFundsTable)
    .where(eq(qurbaniFundsTable.userId, userId))
    .limit(1);

  if (existing[0]) {
    return existing[0];
  }

  const inserted = await db
    .insert(qurbaniFundsTable)
    .values({
      userId,
      title: "রোজা ঈদের গরুর ফান্ড",
      targetAmount: 150000,
      monthlyTarget: 15000,
      eidDate: "2026-05-27",
      notes: "প্রতি মাসে নির্দিষ্ট টাকা জমিয়ে রোজা ঈদের গরুর জন্য প্রস্তুতি।",
    })
    .returning();

  await addActivity(userId, "fund_updated", "নতুন রোজা ঈদের গরুর ফান্ড তৈরি হয়েছে");
  return inserted[0];
}

async function contributionWithMember(userId: string) {
  const rows = await db
    .select({
      id: qurbaniContributionsTable.id,
      memberId: qurbaniContributionsTable.memberId,
      memberName: qurbaniMembersTable.name,
      amount: qurbaniContributionsTable.amount,
      month: qurbaniContributionsTable.month,
      note: qurbaniContributionsTable.note,
      paidAt: qurbaniContributionsTable.paidAt,
    })
    .from(qurbaniContributionsTable)
    .innerJoin(
      qurbaniMembersTable,
      eq(qurbaniContributionsTable.memberId, qurbaniMembersTable.id),
    )
    .where(eq(qurbaniContributionsTable.userId, userId))
    .orderBy(desc(qurbaniContributionsTable.paidAt));

  return rows.map((row) => ({
    id: row.id,
    memberId: row.memberId,
    memberName: row.memberName,
    amount: row.amount,
    month: row.month,
    note: row.note,
    paidAt: toIso(row.paidAt),
  }));
}

router.get("/fund", requireAuth, async (req, res, next) => {
  try {
    const access = await accessFor(req);
    const fund = await ensureFund(access.fundUserId);
    res.json(GetFundResponse.parse(toFund(fund)));
  } catch (err) {
    next(err);
  }
});

router.get("/me", requireAuth, async (req, res, next) => {
  try {
    const access = await accessFor(req);
    res.json(
      GetMeResponse.parse({
        userId: access.userId,
        isAdmin: access.isAdmin,
        role: access.isAdmin ? "admin" : "viewer",
      }),
    );
  } catch (err) {
    next(err);
  }
});

router.put("/fund", requireAuth, async (req, res, next) => {
  try {
    const access = await requireAdmin(req, res);
    if (!access) return;
    const userId = access.fundUserId;
    await ensureFund(userId);
    const body = UpdateFundBody.parse(req.body);
    const rows = await db
      .update(qurbaniFundsTable)
      .set({ ...body, updatedAt: new Date() })
      .where(eq(qurbaniFundsTable.userId, userId))
      .returning();
    await addActivity(userId, "fund_updated", "ফান্ডের লক্ষ্য ও তথ্য আপডেট হয়েছে");
    res.json(UpdateFundResponse.parse(toFund(rows[0])));
  } catch (err) {
    next(err);
  }
});

router.get("/members", requireAuth, async (req, res, next) => {
  try {
    const access = await accessFor(req);
    await ensureFund(access.fundUserId);
    const rows = await db
      .select()
      .from(qurbaniMembersTable)
      .where(eq(qurbaniMembersTable.userId, access.fundUserId))
      .orderBy(desc(qurbaniMembersTable.createdAt));
    res.json(ListMembersResponse.parse(rows.map(toMember)));
  } catch (err) {
    next(err);
  }
});

router.post("/members", requireAuth, async (req, res, next) => {
  try {
    const access = await requireAdmin(req, res);
    if (!access) return;
    const userId = access.fundUserId;
    await ensureFund(userId);
    const body = CreateMemberBody.parse(req.body);
    const rows = await db
      .insert(qurbaniMembersTable)
      .values({ userId, ...body, active: true })
      .returning();
    await addActivity(userId, "member_added", `${body.name} সদস্য হিসেবে যোগ হয়েছে`);
    res.status(201).json(ListMembersResponse.element.parse(toMember(rows[0])));
  } catch (err) {
    next(err);
  }
});

router.patch("/members/:id", requireAuth, async (req, res, next) => {
  try {
    const access = await requireAdmin(req, res);
    if (!access) return;
    const userId = access.fundUserId;
    const params = UpdateMemberParams.parse(req.params);
    const body = UpdateMemberBody.parse(req.body);
    const rows = await db
      .update(qurbaniMembersTable)
      .set(body)
      .where(and(eq(qurbaniMembersTable.userId, userId), eq(qurbaniMembersTable.id, params.id)))
      .returning();
    if (!rows[0]) {
      res.status(404).json({ error: "Member not found" });
      return;
    }
    await addActivity(userId, "member_updated", `${body.name} এর তথ্য আপডেট হয়েছে`);
    res.json(UpdateMemberResponse.parse(toMember(rows[0])));
  } catch (err) {
    next(err);
  }
});

router.delete("/members/:id", requireAuth, async (req, res, next) => {
  try {
    const access = await requireAdmin(req, res);
    if (!access) return;
    const userId = access.fundUserId;
    const params = DeleteMemberParams.parse(req.params);
    const rows = await db
      .update(qurbaniMembersTable)
      .set({ active: false })
      .where(and(eq(qurbaniMembersTable.userId, userId), eq(qurbaniMembersTable.id, params.id)))
      .returning();
    if (!rows[0]) {
      res.status(404).json({ error: "Member not found" });
      return;
    }
    await addActivity(userId, "member_removed", `${rows[0].name} কে বাদ দেওয়া হয়েছে`);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

router.get("/contributions", requireAuth, async (req, res, next) => {
  try {
    const access = await accessFor(req);
    await ensureFund(access.fundUserId);
    res.json(ListContributionsResponse.parse(await contributionWithMember(access.fundUserId)));
  } catch (err) {
    next(err);
  }
});

router.post("/contributions", requireAuth, async (req, res, next) => {
  try {
    const access = await requireAdmin(req, res);
    if (!access) return;
    const userId = access.fundUserId;
    await ensureFund(userId);
    const body = CreateContributionBody.parse(req.body);
    const member = await db
      .select()
      .from(qurbaniMembersTable)
      .where(and(eq(qurbaniMembersTable.userId, userId), eq(qurbaniMembersTable.id, body.memberId)))
      .limit(1);
    if (!member[0]) {
      res.status(404).json({ error: "Member not found" });
      return;
    }
    const rows = await db
      .insert(qurbaniContributionsTable)
      .values({ userId, ...body })
      .returning();
    await addActivity(userId, "contribution_added", `${member[0].name} ${body.amount} টাকা জমা দিয়েছে`);
    const response = {
      id: rows[0].id,
      memberId: rows[0].memberId,
      memberName: member[0].name,
      amount: rows[0].amount,
      month: rows[0].month,
      note: rows[0].note,
      paidAt: toIso(rows[0].paidAt),
    };
    res.status(201).json(UpdateContributionResponse.parse(response));
  } catch (err) {
    next(err);
  }
});

router.patch("/contributions/:id", requireAuth, async (req, res, next) => {
  try {
    const access = await requireAdmin(req, res);
    if (!access) return;
    const userId = access.fundUserId;
    const params = UpdateContributionParams.parse(req.params);
    const body = UpdateContributionBody.parse(req.body);
    const member = await db
      .select()
      .from(qurbaniMembersTable)
      .where(and(eq(qurbaniMembersTable.userId, userId), eq(qurbaniMembersTable.id, body.memberId)))
      .limit(1);
    if (!member[0]) {
      res.status(404).json({ error: "Member not found" });
      return;
    }
    const rows = await db
      .update(qurbaniContributionsTable)
      .set(body)
      .where(
        and(
          eq(qurbaniContributionsTable.userId, userId),
          eq(qurbaniContributionsTable.id, params.id),
        ),
      )
      .returning();
    if (!rows[0]) {
      res.status(404).json({ error: "Contribution not found" });
      return;
    }
    await addActivity(userId, "contribution_updated", `${member[0].name} এর জমার তথ্য আপডেট হয়েছে`);
    res.json(
      UpdateContributionResponse.parse({
        id: rows[0].id,
        memberId: rows[0].memberId,
        memberName: member[0].name,
        amount: rows[0].amount,
        month: rows[0].month,
        note: rows[0].note,
        paidAt: toIso(rows[0].paidAt),
      }),
    );
  } catch (err) {
    next(err);
  }
});

router.delete("/contributions/:id", requireAuth, async (req, res, next) => {
  try {
    const access = await requireAdmin(req, res);
    if (!access) return;
    const userId = access.fundUserId;
    const params = DeleteContributionParams.parse(req.params);
    const rows = await db
      .delete(qurbaniContributionsTable)
      .where(
        and(
          eq(qurbaniContributionsTable.userId, userId),
          eq(qurbaniContributionsTable.id, params.id),
        ),
      )
      .returning();
    if (!rows[0]) {
      res.status(404).json({ error: "Contribution not found" });
      return;
    }
    await addActivity(userId, "contribution_removed", "একটি জমার রেকর্ড মুছে ফেলা হয়েছে");
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

router.get("/dashboard", requireAuth, async (req, res, next) => {
  try {
    const access = await accessFor(req);
    const userId = access.fundUserId;
    const fund = await ensureFund(userId);
    const [memberCounts, totalSavedRows, currentMonthRows, memberTotals, monthlyTotals] =
      await Promise.all([
        db
          .select({
            activeMembers: sql<number>`count(*) filter (where ${qurbaniMembersTable.active} = true)::int`,
            inactiveMembers: sql<number>`count(*) filter (where ${qurbaniMembersTable.active} = false)::int`,
            expected: sql<number>`coalesce(sum(${qurbaniMembersTable.monthlyPledge}) filter (where ${qurbaniMembersTable.active} = true), 0)::float`,
          })
          .from(qurbaniMembersTable)
          .where(eq(qurbaniMembersTable.userId, userId)),
        db
          .select({ total: sql<number>`coalesce(sum(${qurbaniContributionsTable.amount}), 0)::float` })
          .from(qurbaniContributionsTable)
          .where(eq(qurbaniContributionsTable.userId, userId)),
        db
          .select({ total: sql<number>`coalesce(sum(${qurbaniContributionsTable.amount}), 0)::float` })
          .from(qurbaniContributionsTable)
          .where(
            and(
              eq(qurbaniContributionsTable.userId, userId),
              eq(qurbaniContributionsTable.month, new Date().toISOString().slice(0, 7)),
            ),
          ),
        db
          .select({
            memberId: qurbaniMembersTable.id,
            memberName: qurbaniMembersTable.name,
            total: sql<number>`coalesce(sum(${qurbaniContributionsTable.amount}), 0)::float`,
          })
          .from(qurbaniMembersTable)
          .leftJoin(
            qurbaniContributionsTable,
            eq(qurbaniMembersTable.id, qurbaniContributionsTable.memberId),
          )
          .where(eq(qurbaniMembersTable.userId, userId))
          .groupBy(qurbaniMembersTable.id, qurbaniMembersTable.name),
        db
          .select({
            month: qurbaniContributionsTable.month,
            total: sql<number>`coalesce(sum(${qurbaniContributionsTable.amount}), 0)::float`,
          })
          .from(qurbaniContributionsTable)
          .where(eq(qurbaniContributionsTable.userId, userId))
          .groupBy(qurbaniContributionsTable.month)
          .orderBy(qurbaniContributionsTable.month),
      ]);

    const totalSaved = totalSavedRows[0]?.total ?? 0;
    const currentMonthExpected = memberCounts[0]?.expected || fund.monthlyTarget;
    const response = {
      targetAmount: fund.targetAmount,
      monthlyTarget: fund.monthlyTarget,
      totalSaved,
      remainingAmount: Math.max(0, fund.targetAmount - totalSaved),
      activeMembers: memberCounts[0]?.activeMembers ?? 0,
      inactiveMembers: memberCounts[0]?.inactiveMembers ?? 0,
      currentMonthCollected: currentMonthRows[0]?.total ?? 0,
      currentMonthExpected,
      monthsRemaining: monthDiff(new Date(), new Date(fund.eidDate)),
      progressPercent: fund.targetAmount > 0 ? Math.min(100, (totalSaved / fund.targetAmount) * 100) : 0,
      memberTotals,
      monthlyTotals,
    };

    res.json(GetDashboardResponse.parse(response));
  } catch (err) {
    next(err);
  }
});

router.get("/activity", requireAuth, async (req, res, next) => {
  try {
    const access = await accessFor(req);
    const userId = access.fundUserId;
    await ensureFund(userId);
    const rows = await db
      .select()
      .from(qurbaniActivitiesTable)
      .where(eq(qurbaniActivitiesTable.userId, userId))
      .orderBy(desc(qurbaniActivitiesTable.createdAt))
      .limit(20);
    res.json(
      GetActivityResponse.parse(
        rows.map((row) => ({
          id: row.id,
          type: row.type,
          message: row.message,
          createdAt: toIso(row.createdAt),
        })),
      ),
    );
  } catch (err) {
    next(err);
  }
});

export default router;